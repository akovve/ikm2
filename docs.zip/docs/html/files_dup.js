var files_dup =
[
    [ "src", "dir_68267d1309a1af8e8297ef4c3efbcdba.html", "dir_68267d1309a1af8e8297ef4c3efbcdba" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "main.qml", "main_8qml.html", null ]
];