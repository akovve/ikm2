var annotated_dup =
[
    [ "DatabaseManager", "class_database_manager.html", "class_database_manager" ],
    [ "Student", "class_student.html", "class_student" ],
    [ "Subject", "class_subject.html", "class_subject" ],
    [ "Teacher", "class_teacher.html", "class_teacher" ],
    [ "UniversityViewModel", "class_university_view_model.html", "class_university_view_model" ]
];