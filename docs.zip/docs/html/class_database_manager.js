var class_database_manager =
[
    [ "DatabaseManager", "class_database_manager.html#aebfb8cc7427256623ccbe059b30b6450", null ],
    [ "~DatabaseManager", "class_database_manager.html#ae9b3a5da1e04fbb00faf8a034da1d063", null ],
    [ "addStudent", "class_database_manager.html#a81b399a7da98cf9ea99b3d35ef524405", null ],
    [ "addSubject", "class_database_manager.html#af9aa5f94b44794305aabf87706856886", null ],
    [ "addTeacher", "class_database_manager.html#a6b2228573c7cca37f4d92f253a3c0e1e", null ],
    [ "connectToDatabase", "class_database_manager.html#a6eb61705ccd1925062cdd6835afff7f4", null ],
    [ "databaseConnected", "class_database_manager.html#a582b4461e77e9845e1ba5115b114d1d6", null ],
    [ "dataChanged", "class_database_manager.html#a1db64961db807b5d816ffd358d93f0d2", null ],
    [ "deleteStudent", "class_database_manager.html#ad45b95581569764fefd3ecc4cd44b0f6", null ],
    [ "deleteSubject", "class_database_manager.html#a7a9386b64550d768609faf7227878e2d", null ],
    [ "deleteTeacher", "class_database_manager.html#abe33147600a91ed346a8eddc071ed974", null ],
    [ "getAllStudents", "class_database_manager.html#a2c4992fff3cd0c47b06ccf5770a21c2d", null ],
    [ "getAllSubjects", "class_database_manager.html#a352a1254eaf18855012d3efc3de4b725", null ],
    [ "getAllTeachers", "class_database_manager.html#ad983596fc20516e09f7d265b9cbf276e", null ],
    [ "getStudentById", "class_database_manager.html#a5ef7b3f43dd00d37e26a95e53abad3b7", null ],
    [ "getSubjectById", "class_database_manager.html#a41acbbccbbec7c615b8e3c7086d94f3a", null ],
    [ "getTeacherById", "class_database_manager.html#a90aab752b4fa4526946827e6d48920db", null ],
    [ "getTotalRecords", "class_database_manager.html#abbb298eb17fa1eff28ec9f7d1fb3c84a", null ],
    [ "isConnected", "class_database_manager.html#aa4191649a436b20af9d2151e141ee148", null ]
];