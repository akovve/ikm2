var class_subject =
[
    [ "Subject", "class_subject.html#ac78bedb24be6afb83b4fa334badc549b", null ],
    [ "Subject", "class_subject.html#acc22fd470429efdd235dcbb3aa471f8c", null ],
    [ "id", "class_subject.html#aec7b6aeecc6a877672c0e2e8bc5cb509", null ],
    [ "idChanged", "class_subject.html#a73848aad44e35db48b41e6cf7c427154", null ],
    [ "name", "class_subject.html#a60049a78b397f953a7fcee5e132eed21", null ],
    [ "nameChanged", "class_subject.html#a3a8ec402a6d9dba40804eab265064c50", null ],
    [ "setId", "class_subject.html#aeed3ff26555b6c55cd306d0f8f7567c4", null ],
    [ "setName", "class_subject.html#a166e4e70504f82b95571d97d794edf62", null ],
    [ "toString", "class_subject.html#a0368881172dc34239ae6f39fd2e2e5fa", null ],
    [ "id", "class_subject.html#a377b0647cc8da547c5cfc96aacad5b2f", null ],
    [ "name", "class_subject.html#a816225e2744f102877f713f3123a6ba4", null ]
];