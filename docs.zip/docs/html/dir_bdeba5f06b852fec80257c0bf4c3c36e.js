var dir_bdeba5f06b852fec80257c0bf4c3c36e =
[
    [ "DatabaseManager.cpp", "_database_manager_8cpp.html", null ],
    [ "DatabaseManager.h", "_database_manager_8h.html", "_database_manager_8h" ],
    [ "Student.cpp", "_student_8cpp.html", null ],
    [ "Student.h", "_student_8h.html", "_student_8h" ],
    [ "Subject.cpp", "_subject_8cpp.html", null ],
    [ "Subject.h", "_subject_8h.html", "_subject_8h" ],
    [ "Teacher.cpp", "_teacher_8cpp.html", null ],
    [ "Teacher.h", "_teacher_8h.html", "_teacher_8h" ]
];