var _database_manager_8h =
[
    [ "DatabaseManager", "class_database_manager.html", "class_database_manager" ]
];