var _university_view_model_8h =
[
    [ "UniversityViewModel", "class_university_view_model.html", "class_university_view_model" ]
];