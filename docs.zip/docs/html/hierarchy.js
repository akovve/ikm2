var hierarchy =
[
    [ "QObject", null, [
      [ "DatabaseManager", "class_database_manager.html", null ],
      [ "Student", "class_student.html", null ],
      [ "Subject", "class_subject.html", null ],
      [ "Teacher", "class_teacher.html", null ],
      [ "UniversityViewModel", "class_university_view_model.html", null ]
    ] ]
];