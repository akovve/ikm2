var searchData=
[
  ['universityviewmodel_2ecpp_0',['UniversityViewModel.cpp',['../_university_view_model_8cpp.html',1,'']]],
  ['universityviewmodel_2eh_1',['UniversityViewModel.h',['../_university_view_model_8h.html',1,'']]]
];
