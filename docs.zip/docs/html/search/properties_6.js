var searchData=
[
  ['teachers_0',['teachers',['../class_university_view_model.html#aee257b94583aa33bca5b9466f1fc0f13',1,'UniversityViewModel']]],
  ['totalrecords_1',['totalRecords',['../class_university_view_model.html#ae2f05cabc7d523e1d8babb0256b020cc',1,'UniversityViewModel']]]
];
