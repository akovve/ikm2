var searchData=
[
  ['databasemanager_0',['DatabaseManager',['../class_database_manager.html',1,'']]]
];
