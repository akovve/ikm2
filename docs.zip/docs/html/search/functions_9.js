var searchData=
[
  ['refresh_0',['refresh',['../class_university_view_model.html#a7d92f81f646515989c75b53af7559986',1,'UniversityViewModel']]]
];
