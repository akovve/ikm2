var searchData=
[
  ['setdepartment_0',['setDepartment',['../class_teacher.html#ab71128289f503af699cc0a8a1fa7c76b',1,'Teacher']]],
  ['setfullname_1',['setFullName',['../class_student.html#a8a1081dec781bc05d6ef9b405cf7f897',1,'Student::setFullName()'],['../class_teacher.html#a05c6f765e56bd761ee2faeae7c39af8f',1,'Teacher::setFullName()']]],
  ['setgrade_2',['setGrade',['../class_student.html#a9547c17d28385d164335384622218551',1,'Student']]],
  ['setid_3',['setId',['../class_student.html#abba5d240dcfdcdaf3a030e3e1c4ad1f6',1,'Student::setId()'],['../class_subject.html#aeed3ff26555b6c55cd306d0f8f7567c4',1,'Subject::setId()'],['../class_teacher.html#a656b4b4da06c184d438220b1bf6ec5da',1,'Teacher::setId()']]],
  ['setname_4',['setName',['../class_subject.html#a166e4e70504f82b95571d97d794edf62',1,'Subject']]],
  ['student_5',['Student',['../class_student.html',1,'Student'],['../class_student.html#abc29f15dfff75347842b591dc34b8a93',1,'Student::Student(QObject *parent=nullptr)'],['../class_student.html#a790b1d543766311905e7ee674ecf9814',1,'Student::Student(int id, const QString &amp;fullName, int grade, QObject *parent=nullptr)']]],
  ['student_2ecpp_6',['Student.cpp',['../_student_8cpp.html',1,'']]],
  ['student_2eh_7',['Student.h',['../_student_8h.html',1,'']]],
  ['students_8',['students',['../class_university_view_model.html#af0fcb1bc0b9d63016d67968660f8b6fe',1,'UniversityViewModel::students'],['../class_university_view_model.html#a67ceef4edf89f770638a9430c9339b09',1,'UniversityViewModel::students() const']]],
  ['subject_9',['Subject',['../class_subject.html',1,'Subject'],['../class_subject.html#ac78bedb24be6afb83b4fa334badc549b',1,'Subject::Subject(QObject *parent=nullptr)'],['../class_subject.html#acc22fd470429efdd235dcbb3aa471f8c',1,'Subject::Subject(int id, const QString &amp;name, QObject *parent=nullptr)']]],
  ['subject_2ecpp_10',['Subject.cpp',['../_subject_8cpp.html',1,'']]],
  ['subject_2eh_11',['Subject.h',['../_subject_8h.html',1,'']]],
  ['subjects_12',['subjects',['../class_university_view_model.html#a23268e3bd77bf02f47b107a560b8eb1f',1,'UniversityViewModel::subjects'],['../class_university_view_model.html#a6c62af39a419b7ead5222d2ee89f1ea1',1,'UniversityViewModel::subjects() const']]],
  ['system_13',['University Database Management System',['../index.html',1,'']]]
];
