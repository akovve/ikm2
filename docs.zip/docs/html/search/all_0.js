var searchData=
[
  ['addstudent_0',['addStudent',['../class_database_manager.html#a81b399a7da98cf9ea99b3d35ef524405',1,'DatabaseManager::addStudent()'],['../class_university_view_model.html#ab05eeea75aa22665aaeb6b1997a8c687',1,'UniversityViewModel::addStudent()']]],
  ['addsubject_1',['addSubject',['../class_database_manager.html#af9aa5f94b44794305aabf87706856886',1,'DatabaseManager::addSubject()'],['../class_university_view_model.html#a6a693cc485e3d80a5c819f7bac5827b1',1,'UniversityViewModel::addSubject()']]],
  ['addteacher_2',['addTeacher',['../class_database_manager.html#a6b2228573c7cca37f4d92f253a3c0e1e',1,'DatabaseManager::addTeacher()'],['../class_university_view_model.html#a89c1c8896edbab53a69dc9681c2ae14b',1,'UniversityViewModel::addTeacher()']]]
];
