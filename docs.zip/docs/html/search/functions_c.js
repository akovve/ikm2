var searchData=
[
  ['universityviewmodel_0',['UniversityViewModel',['../class_university_view_model.html#a2b7a43f6407fe80c61a32172aaf95efe',1,'UniversityViewModel']]]
];
