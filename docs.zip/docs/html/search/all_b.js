var searchData=
[
  ['teacher_0',['Teacher',['../class_teacher.html',1,'Teacher'],['../class_teacher.html#abf6951eae54db538295fc8ca31eb0e3f',1,'Teacher::Teacher(QObject *parent=nullptr)'],['../class_teacher.html#ad7cb6cd52f75550a810552977e9162c0',1,'Teacher::Teacher(int id, const QString &amp;fullName, const QString &amp;department, QObject *parent=nullptr)']]],
  ['teacher_2ecpp_1',['Teacher.cpp',['../_teacher_8cpp.html',1,'']]],
  ['teacher_2eh_2',['Teacher.h',['../_teacher_8h.html',1,'']]],
  ['teachers_3',['teachers',['../class_university_view_model.html#aee257b94583aa33bca5b9466f1fc0f13',1,'UniversityViewModel::teachers'],['../class_university_view_model.html#a1a4ceecfe41cd1a3494b16eb02cf87a1',1,'UniversityViewModel::teachers() const']]],
  ['tostring_4',['toString',['../class_student.html#a3d53d2fd4a6d02c99d1c3e1a210d5e23',1,'Student::toString()'],['../class_subject.html#a0368881172dc34239ae6f39fd2e2e5fa',1,'Subject::toString()'],['../class_teacher.html#ab37d0e399bc5077beb3c8db2cc8e66e7',1,'Teacher::toString()']]],
  ['totalrecords_5',['totalRecords',['../class_university_view_model.html#ae2f05cabc7d523e1d8babb0256b020cc',1,'UniversityViewModel::totalRecords'],['../class_university_view_model.html#afcbb701373ac2005297956be48b553b1',1,'UniversityViewModel::totalRecords() const']]]
];
