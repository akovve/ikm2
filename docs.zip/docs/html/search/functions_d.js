var searchData=
[
  ['_7edatabasemanager_0',['~DatabaseManager',['../class_database_manager.html#ae9b3a5da1e04fbb00faf8a034da1d063',1,'DatabaseManager']]],
  ['_7euniversityviewmodel_1',['~UniversityViewModel',['../class_university_view_model.html#a44faa8c8a4e9f016d0deb417ea14791b',1,'UniversityViewModel']]]
];
