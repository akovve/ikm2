var searchData=
[
  ['erroroccurred_0',['errorOccurred',['../class_university_view_model.html#a2562a1c19cc5eeefd36ede3b52187a39',1,'UniversityViewModel']]]
];
