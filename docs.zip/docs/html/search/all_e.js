var searchData=
[
  ['архитектура_0',['Архитектура',['../index.html#arch_sec',1,'']]]
];
