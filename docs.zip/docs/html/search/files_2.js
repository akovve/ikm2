var searchData=
[
  ['main_2ecpp_0',['main.cpp',['../main_8cpp.html',1,'']]],
  ['main_2eqml_1',['main.qml',['../main_8qml.html',1,'']]]
];
