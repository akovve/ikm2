var searchData=
[
  ['databasemanager_2ecpp_0',['DatabaseManager.cpp',['../_database_manager_8cpp.html',1,'']]],
  ['databasemanager_2eh_1',['DatabaseManager.h',['../_database_manager_8h.html',1,'']]]
];
