var searchData=
[
  ['student_0',['Student',['../class_student.html',1,'']]],
  ['subject_1',['Subject',['../class_subject.html',1,'']]]
];
