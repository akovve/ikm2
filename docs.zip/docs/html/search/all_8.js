var searchData=
[
  ['name_0',['name',['../class_subject.html#a816225e2744f102877f713f3123a6ba4',1,'Subject::name'],['../class_subject.html#a60049a78b397f953a7fcee5e132eed21',1,'Subject::name() const']]],
  ['namechanged_1',['nameChanged',['../class_subject.html#a3a8ec402a6d9dba40804eab265064c50',1,'Subject']]]
];
