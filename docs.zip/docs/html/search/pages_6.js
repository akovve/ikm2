var searchData=
[
  ['основные_20возможности_0',['Основные возможности',['../index.html#features_sec',1,'']]]
];
