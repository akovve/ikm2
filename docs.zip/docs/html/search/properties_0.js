var searchData=
[
  ['department_0',['department',['../class_teacher.html#a36065081c65905de6a0f0a4a6a4a2665',1,'Teacher']]]
];
