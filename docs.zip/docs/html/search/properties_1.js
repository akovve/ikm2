var searchData=
[
  ['fullname_0',['fullName',['../class_student.html#a0abbaea70beb713544dc92d02db1add7',1,'Student::fullName'],['../class_teacher.html#abb17edb440cd863575b2f1507930cd41',1,'Teacher::fullName']]]
];
