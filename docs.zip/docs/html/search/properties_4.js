var searchData=
[
  ['name_0',['name',['../class_subject.html#a816225e2744f102877f713f3123a6ba4',1,'Subject']]]
];
