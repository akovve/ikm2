var searchData=
[
  ['fullname_0',['fullName',['../class_student.html#a0abbaea70beb713544dc92d02db1add7',1,'Student::fullName'],['../class_teacher.html#abb17edb440cd863575b2f1507930cd41',1,'Teacher::fullName'],['../class_student.html#a81ff6e64d22222705e711198017302dc',1,'Student::fullName()'],['../class_teacher.html#a735b44d3c801f55ffb8cecc64b5d0b59',1,'Teacher::fullName()']]],
  ['fullnamechanged_1',['fullNameChanged',['../class_student.html#adca0fe864bc4b5d7bd4cec03664dfae4',1,'Student::fullNameChanged()'],['../class_teacher.html#a1bad6ac54875fb4e70c7db907e83eb03',1,'Teacher::fullNameChanged()']]]
];
