var searchData=
[
  ['введение_0',['Введение',['../index.html#intro_sec',1,'']]],
  ['возможности_1',['Основные возможности',['../index.html#features_sec',1,'']]]
];
