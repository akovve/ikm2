var searchData=
[
  ['database_20management_20system_0',['University Database Management System',['../index.html',1,'']]],
  ['databaseconnected_1',['databaseConnected',['../class_database_manager.html#a582b4461e77e9845e1ba5115b114d1d6',1,'DatabaseManager']]],
  ['databasemanager_2',['DatabaseManager',['../class_database_manager.html',1,'DatabaseManager'],['../class_database_manager.html#aebfb8cc7427256623ccbe059b30b6450',1,'DatabaseManager::DatabaseManager()']]],
  ['databasemanager_2ecpp_3',['DatabaseManager.cpp',['../_database_manager_8cpp.html',1,'']]],
  ['databasemanager_2eh_4',['DatabaseManager.h',['../_database_manager_8h.html',1,'']]],
  ['datachanged_5',['dataChanged',['../class_database_manager.html#a1db64961db807b5d816ffd358d93f0d2',1,'DatabaseManager::dataChanged()'],['../class_university_view_model.html#a4f3547b679e2498565a1efaed619f0b1',1,'UniversityViewModel::dataChanged()']]],
  ['deletestudent_6',['deleteStudent',['../class_database_manager.html#ad45b95581569764fefd3ecc4cd44b0f6',1,'DatabaseManager::deleteStudent()'],['../class_university_view_model.html#af29fe1a670045f9044889fe7dfd26fd7',1,'UniversityViewModel::deleteStudent()']]],
  ['deletesubject_7',['deleteSubject',['../class_database_manager.html#a7a9386b64550d768609faf7227878e2d',1,'DatabaseManager::deleteSubject()'],['../class_university_view_model.html#ac73a47dbc722fa61cfa22315c172e6b6',1,'UniversityViewModel::deleteSubject()']]],
  ['deleteteacher_8',['deleteTeacher',['../class_database_manager.html#abe33147600a91ed346a8eddc071ed974',1,'DatabaseManager::deleteTeacher()'],['../class_university_view_model.html#ae5bd736d878445f3368e53e0e5d36d93',1,'UniversityViewModel::deleteTeacher()']]],
  ['department_9',['department',['../class_teacher.html#a36065081c65905de6a0f0a4a6a4a2665',1,'Teacher::department'],['../class_teacher.html#a0fe7ee1084c250c8757a7bdab3fa1f55',1,'Teacher::department() const']]],
  ['departmentchanged_10',['departmentChanged',['../class_teacher.html#ae426f9e6a21e8532527523255269cce3',1,'Teacher']]]
];
