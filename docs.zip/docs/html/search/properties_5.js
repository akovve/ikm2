var searchData=
[
  ['students_0',['students',['../class_university_view_model.html#af0fcb1bc0b9d63016d67968660f8b6fe',1,'UniversityViewModel']]],
  ['subjects_1',['subjects',['../class_university_view_model.html#a23268e3bd77bf02f47b107a560b8eb1f',1,'UniversityViewModel']]]
];
