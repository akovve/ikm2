var searchData=
[
  ['id_0',['id',['../class_student.html#a1351fb239711a78a8b115d75597b5df0',1,'Student::id'],['../class_subject.html#a377b0647cc8da547c5cfc96aacad5b2f',1,'Subject::id'],['../class_teacher.html#a11a47f241400b71e753b8149fc88d8dc',1,'Teacher::id']]],
  ['isconnected_1',['isConnected',['../class_university_view_model.html#a1198c2612b4c33f02d17ad5b62a161be',1,'UniversityViewModel']]]
];
