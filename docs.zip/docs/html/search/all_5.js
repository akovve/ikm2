var searchData=
[
  ['getallstudents_0',['getAllStudents',['../class_database_manager.html#a2c4992fff3cd0c47b06ccf5770a21c2d',1,'DatabaseManager']]],
  ['getallsubjects_1',['getAllSubjects',['../class_database_manager.html#a352a1254eaf18855012d3efc3de4b725',1,'DatabaseManager']]],
  ['getallteachers_2',['getAllTeachers',['../class_database_manager.html#ad983596fc20516e09f7d265b9cbf276e',1,'DatabaseManager']]],
  ['getstudentbyid_3',['getStudentById',['../class_database_manager.html#a5ef7b3f43dd00d37e26a95e53abad3b7',1,'DatabaseManager']]],
  ['getsubjectbyid_4',['getSubjectById',['../class_database_manager.html#a41acbbccbbec7c615b8e3c7086d94f3a',1,'DatabaseManager']]],
  ['getteacherbyid_5',['getTeacherById',['../class_database_manager.html#a90aab752b4fa4526946827e6d48920db',1,'DatabaseManager']]],
  ['gettotalrecords_6',['getTotalRecords',['../class_database_manager.html#abbb298eb17fa1eff28ec9f7d1fb3c84a',1,'DatabaseManager']]],
  ['grade_7',['grade',['../class_student.html#a6ccb1dafc8372525128a418b99597aaa',1,'Student::grade'],['../class_student.html#adab6f60fbc1aca5fca0e15cfc10baae5',1,'Student::grade() const']]],
  ['gradechanged_8',['gradeChanged',['../class_student.html#ad34bdd58648c0f16073b1e404fe6d180',1,'Student']]]
];
