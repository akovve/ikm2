var searchData=
[
  ['universityviewmodel_0',['UniversityViewModel',['../class_university_view_model.html',1,'']]]
];
