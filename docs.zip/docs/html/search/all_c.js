var searchData=
[
  ['university_20database_20management_20system_0',['University Database Management System',['../index.html',1,'']]],
  ['universityviewmodel_1',['UniversityViewModel',['../class_university_view_model.html',1,'UniversityViewModel'],['../class_university_view_model.html#a2b7a43f6407fe80c61a32172aaf95efe',1,'UniversityViewModel::UniversityViewModel()']]],
  ['universityviewmodel_2ecpp_2',['UniversityViewModel.cpp',['../_university_view_model_8cpp.html',1,'']]],
  ['universityviewmodel_2eh_3',['UniversityViewModel.h',['../_university_view_model_8h.html',1,'']]]
];
