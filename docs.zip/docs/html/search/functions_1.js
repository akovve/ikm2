var searchData=
[
  ['cmake_5fminimum_5frequired_0',['cmake_minimum_required',['../_c_make_lists_8txt.html#a3fb6fd285087020ace1035c76db90243',1,'CMakeLists.txt']]],
  ['connectionchanged_1',['connectionChanged',['../class_university_view_model.html#a2328cec94e18e9b1df54cb7bf42f228b',1,'UniversityViewModel']]],
  ['connecttodatabase_2',['connectToDatabase',['../class_database_manager.html#a6eb61705ccd1925062cdd6835afff7f4',1,'DatabaseManager::connectToDatabase()'],['../class_university_view_model.html#aff399499f7893b9e5e52bdafa989f8e4',1,'UniversityViewModel::connectToDatabase()']]]
];
