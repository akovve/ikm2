var searchData=
[
  ['management_20system_0',['University Database Management System',['../index.html',1,'']]]
];
