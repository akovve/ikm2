var class_student =
[
    [ "Student", "class_student.html#abc29f15dfff75347842b591dc34b8a93", null ],
    [ "Student", "class_student.html#a790b1d543766311905e7ee674ecf9814", null ],
    [ "fullName", "class_student.html#a81ff6e64d22222705e711198017302dc", null ],
    [ "fullNameChanged", "class_student.html#adca0fe864bc4b5d7bd4cec03664dfae4", null ],
    [ "grade", "class_student.html#adab6f60fbc1aca5fca0e15cfc10baae5", null ],
    [ "gradeChanged", "class_student.html#ad34bdd58648c0f16073b1e404fe6d180", null ],
    [ "id", "class_student.html#a22139db1207705d1c5952ad34be02a56", null ],
    [ "idChanged", "class_student.html#ac33bca171b60914efac613b4707ddb52", null ],
    [ "setFullName", "class_student.html#a8a1081dec781bc05d6ef9b405cf7f897", null ],
    [ "setGrade", "class_student.html#a9547c17d28385d164335384622218551", null ],
    [ "setId", "class_student.html#abba5d240dcfdcdaf3a030e3e1c4ad1f6", null ],
    [ "toString", "class_student.html#a3d53d2fd4a6d02c99d1c3e1a210d5e23", null ],
    [ "fullName", "class_student.html#a0abbaea70beb713544dc92d02db1add7", null ],
    [ "grade", "class_student.html#a6ccb1dafc8372525128a418b99597aaa", null ],
    [ "id", "class_student.html#a1351fb239711a78a8b115d75597b5df0", null ]
];