var dir_00596377d40923a735e6869bcc6fcb02 =
[
    [ "UniversityViewModel.cpp", "_university_view_model_8cpp.html", null ],
    [ "UniversityViewModel.h", "_university_view_model_8h.html", "_university_view_model_8h" ]
];